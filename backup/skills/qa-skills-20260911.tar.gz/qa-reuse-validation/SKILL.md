---
name: qa-reuse-validation
description: >
  当用户提供仓库地址、测试环境 URL、账号密码等"待测试/待验证"信息时，在生成任何测试代码或重新搭建脚本之前，
  必须先核对「已完成功能清单」与项目记忆，复用既有能力/脚本/用例，禁止把已实现的同类功能当全新功能重新生成。
  触发词："在 X 地址测试"、"测试这个仓库"、"根据扫描生成的用例测试"、"重新验证"、"跑一遍"、
  "验证一下"、"用环境 Y 测试"、"对 Z 分支做测试"。Also apply whenever a request bundles a repo URL +
  credentials with a "test/validate/verify/execute" verb, or mentions a target env that has appeared before.
agent_created: true
---

# Reuse-First Validation（先复用，再生成）

用户反复反馈：每次提供仓库地址 / 测试环境 / 账号，都会被当成全新功能重新验证并生成代码，
而大量能力其实昨天/此前已做过（test-accel 平台能力、福享 Agent 线上 Playwright 测试、research-agent
浅克隆处理、统一登录选择器等）。本技能强制"先查清单再动手"，从根上消除重复生成。

## 铁律（每个"测试 / 验证"类请求的第一步，不是 clone / fetch / 写脚本）
1. **先查清单，再动手。** 读取项目根 `.workbuddy/memory/COMPLETED_FEATURES.md`（若存在），
   同时读 `.workbuddy/memory/MEMORY.md`。本机已有大量"已解决"事实（浅克隆陷阱、codeup 直连、
   `47.97.154.50:8090` = 福享 Agent、test_ft001 登录选择器、test-accel 平台端点……）。
2. **意图判别**（决定"复用"还是"新建"）：
   - 含「验证 / 测试 / 执行 / 跑一遍 / 回归 / 确认可用」→ **默认复用**：定位既有 harness / cases，
     直接指向它、运行它、报告结果。**不**重写脚本、**不**重装无关依赖、**不**重做 recon。
   - 含「实现 / 新增 / 构建 / 新建 / 从零 / 脚手架」→ 才允许新建，但仍先查是否有可平移的纯逻辑。
3. **环境即已知事实**：若 URL / 账号在记忆或清单中已出现，直接套用既有登录选择器 / 端口 / 凭证，
   不要重新走侦察（recon）。

## 复用检查清单（动手前 30 秒）
- [ ] `COMPLETED_FEATURES.md` 是否已有该 repo / 该 env / 该意图的条目？
- [ ] 该 repo 之前是否被克隆 / 加深过？（查 `work/targets`、git shallow 状态，别重复 deepen）
- [ ] 该测试环境是否已有 Playwright / 接口 harness？（查 `_fx_test`、test-accel 平台、历史脚本）
- [ ] 该"功能"是否已是 test-accel 平台已有端点？（`scan_and_test` / `diff_analyze` / `smoke` / `cases`）
- [ ] 用户说的是"验证"（复用 + 跑）还是"实现"（新建）？

## 何时才生成新代码（仅当以下任一为真）
- 清单 / 记忆中**确实没有**覆盖该 repo + env + 意图的既有能力；
- 用户明确说了"实现 / 新建 / 从零"；
- 既有 harness 因环境变化（如分支大改、接口重构）确实失效——且**先确认失效**再补，不要默认重写。

## 完成后必须回写
每完成一个可复用能力，立即向 `COMPLETED_FEATURES.md` 追加一条
（`功能 | 代码位置 | 如何调用 | 验证过的环境 | [REUSE] 标记`），使下次"测试 / 验证"请求能直接命中。
这是让本技能长期有效的前提——**状态在清单，行为在技能**。

## 参考
- `~/.workbuddy/skills/windows-browser-e2e-selftest`：本机 Playwright + 系统浏览器 E2E 套路。
- 项目记忆 `MEMORY.md` 已记录 research-agent 浅克隆陷阱、codeup 直连、test-accel 平台端点。
- `COMPLETED_FEATURES.md`：本机已建成能力的权威登记表（优先于从零重建）。
