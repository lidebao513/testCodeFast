#!/usr/bin/env python3
# ============================================================================
# qa-code-pull · 薄壳委托脚本
# ----------------------------------------------------------------------------
# 核心实现位于工程内唯一真源：
#   <repo>/work/test-accel/scripts/pull_code.py（纳入统一质量门禁 gate_all.py 扫描）
# 本文件仅负责定位并以子进程方式调用该实现，使技能仍可独立 `python pull_code.py`。
#
# 定位顺序（不硬编码个人绝对路径）：
#   1) 环境变量 QA_PULL_CODE_IMPL 指定的实现文件；
#   2) 环境变量 QA_PROJECT_ROOT 下的 work/test-accel/scripts/pull_code.py；
#   3) 从当前工作目录逐级向上查找 work/test-accel/scripts/pull_code.py。
# 合规说明见配套 SKILL.md（§八 实现位置）。
# ============================================================================
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

_IMPL_REL = Path("work") / "test-accel" / "scripts" / "pull_code.py"


def _candidate_from_env() -> Path | None:
    env = os.environ.get("QA_PULL_CODE_IMPL", "")
    if env:
        cand = Path(env)
        if cand.is_file():
            return cand
    root = os.environ.get("QA_PROJECT_ROOT", "")
    if root:
        cand = Path(root) / _IMPL_REL
        if cand.is_file():
            return cand
    return None


def _search_upward() -> Path | None:
    """从当前工作目录逐级向上查找 <repo>/work/test-accel/scripts/pull_code.py。"""
    try:
        cur = Path.cwd().resolve()
    except Exception:
        return None
    for base in (cur, *cur.parents):
        cand = base / _IMPL_REL
        if cand.is_file():
            return cand
    return None


def _find_impl() -> Path | None:
    return _candidate_from_env() or _search_upward()


def main() -> int:
    impl = _find_impl()
    if impl is None:
        sys.stderr.write(
            "未找到 pull_code.py 实现（期望：<repo>/work/test-accel/scripts/pull_code.py）。\n"
            "请在仓库根目录下运行，或用 QA_PROJECT_ROOT / QA_PULL_CODE_IMPL 指定位置。\n"
        )
        return 1
    cmd = [sys.executable, str(impl), *sys.argv[1:]]
    return subprocess.run(cmd, cwd=str(impl.parent.parent)).returncode


if __name__ == "__main__":
    raise SystemExit(main())
