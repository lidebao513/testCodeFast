---
name: qa-code-pull
description: >
  「拉取代码」独立技能：克隆 / 更新 / 加深（解决浅克隆 git diff 失真）/ 确认 diff 基线与目标
  ref / 将工作树切到目标版本 / 计算 base..target 变更文件集合（或就地基线模式下比较
  工作树 vs 基线）。含**防误伤父仓库安全网**（git 顶层逃逸即阻断）。当用户给出仓库地址或分支对比基线、
  要求「拉取 / 同步 / 更新代码 / 准备被测代码 / 拿到变更文件」时使用。与「测试点(qa-test-points)」技能
  完全解耦：本技能只负责把代码「备好并就位」，不生成测试点；也不 import 任何测试点 / 平台模块，
  环境变量命名空间隔离（REPO_URL / LOCAL_PATH / DIFF_BASE / DIFF_TARGET / DEEPEN / PULL_RESULT_JSON），
  通过文件系统契约（写 result JSON）与下游通信，互不干扰、无报错、运行稳定。
agent_created: true
---

# 拉取代码（qa-code-pull）独立技能

把「获取被测代码并使其可用于分析」这件事从「测试点」等其他能力中**彻底剥离**为单一职责模块。

## 一、何时使用（触发条件）
- 用户给出仓库地址 / 分支 / 对比基线，要求「拉取代码」「同步最新」「更新代码」「准备被测代码」。
- 需要在生成测试点 / 做 diff 分析 **之前**，确保目标仓库存在、历史足够深、工作树处于目标版本、且能拿到变更文件。
- 发现 `git diff` 失真（浅克隆陷阱）时，需要加深历史后再对比。

> 不触发：仅要"生成测试点"而代码已就位时，直接走 `qa-test-points`，不必重复调用本技能。

## 二、入参（环境变量 或 命令行 --key，命名空间独立，不与 qa-test-points 冲突）
| 参数 | 环境变量 | 默认 | 说明 |
|---|---|---|---|
| `--url` | `REPO_URL` | 空（已存在仓库自动读 remote） | 仅克隆时需要 |
| `--path` | `LOCAL_PATH` | `work/targets/research-agent` | 本地仓库路径（必填/有默认） |
| `--base` | `DIFF_BASE` | `HEAD` | diff 基线 ref（默认 HEAD，配合 --target WORKTREE 走就地基线模式） |
| `--target` | `DIFF_TARGET` | `WORKTREE` | diff 目标 ref（默认 WORKTREE：分析当前工作树相对基线变更） |
| `--deepen` | `DEEPEN` | `300` | 浅克隆加深深度 |
| `--out` | `PULL_RESULT_JSON` | `<path父目录>/.pull_result.json` | 结果 JSON 落盘路径 |

## 三、调用时机（与其他技能的顺序）
**先 `qa-code-pull`，后 `qa-test-points`（或 diff 分析）。** 本技能是「被测代码准备」前置步骤，不依赖、也不调用下游。

## 四、处理流程（幂等、可离线降级）
0. **目录三态判定（硬性安全网）**（`classify_target()` 唯一入口）：
   - **目录不存在（missing）** → 直接克隆；
   - **存在但非 git 仓库（not_repo）** → 允许克隆进入：空目录正常克隆；非空目录无法 clone，
     返回 `status="target_not_empty"` 并给出清理/换路径指引（**不再误判为"逃逸"**）；
   - **存在且为 git 仓库根（repo）** → 正常使用；
   - **位于祖先仓库内部（escape）** → 立即返回 `status="repo_escape_blocked"` 并拒绝任何
     diff/checkout，杜绝误改父项目（典型：被测目录 `.git` 损坏，git 向上解析到项目根）。
1. **就绪**：仓库不存在 → 克隆（codeup 直连 + `protocol.version=0`，浅克隆起步）；已存在 → 读 `remote.origin.url`。
   POSIX 下若 URL 内嵌 `user:pass@` 凭据，会剥离后经 `GIT_ASKPASS` 注入，**凭据不出现在进程 argv**。
2. **加深**：`git rev-parse --is-shallow-repository` 为 true → `fetch --deepen` + 拉取 base/target ref（解决浅克隆 `git diff` 失真）。
3. **更新**：`git fetch --tags origin`；离线则跳过，不影响本地分析。
4. **确 ref**：base / target 不可解析 → 尝试 `fetch origin <ref>`。
5. **就位**：`git checkout -f <target>`，使工作树 = 目标版本（测试点分析的是工作树内容）。
6. **变更集**：
   - 双 ref 模式：`git diff --name-only base..target`。
   - **就地基线模式**（`--target WORKTREE` 或空）：`git diff --name-only <base>` + `git status --porcelain`
     中的未跟踪文件 → 工作树相对基线提交的变更集合（被测代码更新即知改了哪些）。

> **当前被测仓库状态（2026-09-08）**：`work/targets/research-agent` 已是**就地 `git init` 的真实独立仓库**
> （分支 `main`，含一个基线提交）。无远程、无 base/target 历史 ref，故默认走**就地基线模式**：
> `python pull_code.py --base HEAD --target WORKTREE` 即可算出"相对上次基线的增量"。
> 若要恢复 `base..target` 双 ref 对比，需先给令牌做真·远程克隆（见 §八网络与凭证）。

## 五、结果（输出）
- 控制台打印订阅式摘要；完整结果写 `--out` 指定的 JSON（默认 `<path父目录>/.pull_result.json`）。
- 结构：
```json
{
  "status": "ok | ok_offline | refs_unavailable | clone_failed | repo_escape_blocked | clone_required_no_url | target_not_empty",
  "success": true/false,
  "mode": "dual_ref | worktree",
  "url": "...", "local_path": "...", "base": "...", "target": "...",
  "shallow": true/false, "deepened": true/false,
  "fetch_status": "fetched | skipped_offline | deepen_failed | worktree",
  "checked_out": "test-20260907 | WORKTREE(分析当前工作树)",
  "base_sha": "...", "target_sha": "...",
  "changed_count": 64, "changed_files": ["..."],
  "perm": { "readonly_before_pull": true, "restored_after_pull": true, "note": "..." },
  "errors": []
}
```
> 注：`success` 为本次新增的「是否成功」布尔字段（消费方应据此强校验，避免静默透传）；
> `mode` 标识变更集计算模式；`perm` 始终存在，反映只读权限管控状态。
- **下游契约**：`qa-test-points` 通过 `CHANGED_FILES_JSON` 环境变量（指向本结果的 JSON 文件，取其中 `changed_files` 列表）消费变更集；不读则测试点内部按默认 base..target 自行计算。

## 六、稳定性 / 互不干扰保证
- **不依赖 qa-test-points**：纯标准库 + `subprocess(git)`，零跨模块 import。
- **仅读/写自有资源**：写仓库（fetch/checkout）、写自有 result JSON；**不触碰** qa-test-points 的产物目录（`work/research-agent-test/`）。
- **离线优雅降级**：所有网络 git 操作均 `try/except + 超时` 包裹；网络不可用时 `status=ok_offline`、用本地已有数据产出结果，**绝不抛未捕获异常，进程退出码恒为 0**，调用方不会因本技能而"报错"。
- **环境变量隔离**：本技能只用 `REPO_URL/LOCAL_PATH/DIFF_BASE/DIFF_TARGET/DEEPEN/PULL_RESULT_JSON`，与 qa-test-points 的 `TP_*` 命名空间不重叠。

## 七、与 qa-test-points 的调用规则（速查 · 互不干扰）★ 本技能与 `qa-test-points` 完全独立
| 维度 | qa-code-pull（拉取代码） | qa-test-points（生成测试点） |
|---|---|---|
| 触发条件 | 给出仓库/分支/基线，要「拉取/同步/准备被测代码」 | 要「生成测试点/测试范围/测试覆盖」 |
| 入参命名空间 | `REPO_URL`/`LOCAL_PATH`/`DIFF_BASE`/`DIFF_TARGET`/`DEEPEN`/`PULL_RESULT_JSON` | `TP_REPO_PATH`/`TP_DIFF_BASE`/`TP_DIFF_TARGET`/`CHANGED_FILES_JSON`/`TP_SCOPE` |
| 调用时机 | **先** | **后** |
| 是否依赖对方 | 否（独立克隆/加深/切版本） | 否（只读工作树；变更集可经 `CHANGED_FILES_JSON` 读取，亦可内部计算） |
| 互相 import | 无 | 无 |
| 写出的资源 | 改仓库（fetch/checkout）+ 自有 `.pull_result.json` | `work/research-agent-test/` 下 4 文件 |
| 稳定性保证 | 网络操作全部 try/except+超时+killpg，离线降级，退出码恒 0 | read-only，纯本地文件扫描，不触网 |

- 衔接契约：本技能把 `changed_files` 写入 `PULL_RESULT_JSON`（默认 `work/targets/.pull_result.json`）；
  `qa-test-points` 经 `CHANGED_FILES_JSON` 指向该文件即**解耦消费**，不调用 git、不 import 本技能。
- 命名空间隔离（`REPO_*`/`PULL_*` vs `TP_*`）确保两者参数不串扰；资源分区（仓库 vs `research-agent-test/`）确保不互删。
- 顺序约定：本技能完成（仓库就位、工作树=目标版本）后再跑 qa-test-points，避免读到不一致工作树。

## 八、实现位置
- **唯一真源（工程内，纳入统一门禁）**：`work/test-accel/scripts/pull_code.py`
  （被 `scripts/gate_all.py` 的 ruff / mypy / bandit / pytest **全覆盖**；
  状态/模式字符串由模块内 `PullStatus` / `PullMode` / `FetchStatus` 枚举单源定义，
  且 `PullStatus` 与 `backend/core/enums.py::PullStatus` 逐值一致，由单测守护）。
- **技能薄壳委托**：`~/.workbuddy/skills/qa-code-pull/pull_code.py` 仅定位并子进程调用上述实现。
  定位顺序：`QA_PULL_CODE_IMPL` → `QA_PROJECT_ROOT/work/test-accel/scripts/pull_code.py`
  → **从当前工作目录逐级向上查找**（不再硬编码个人绝对路径）。
- 历史说明：本模块原内联于技能目录；2026-09-11 评审后迁至工程内以满足「枚举单源 + 纳入门禁」规范。
- 网络与凭证（本机规则，归档于项目 MEMORY）：
  - 阿里云 codeup：直连快、代理慢；内网 git 用 `protocol.version=0` 浅取。
  - GitHub 仅 SSH 可用（HTTPS 被拦截）；本技能不处理 GitHub 鉴权。
  - 仓库真实地址经 `.env` 的 `RA_GIT_URL` 注入，不入库。

## 九、调用示例
```bash
cd ~/.workbuddy/skills/qa-code-pull
# 默认（就手项目，离线亦可用本地数据）
python pull_code.py
# 指定仓库与基线
REPO_URL="https://oauth2:<token>@codeup.aliyun.com/.../research-agent.git" \
LOCAL_PATH="work/targets/research-agent" \
DIFF_BASE="test-20260906" DIFF_TARGET="test-20260907" \
python pull_code.py
# ★ 就地基线模式：被测代码更新后，算"相对上次基线的增量"（无需远程）
LOCAL_PATH="work/targets/research-agent" \
DIFF_BASE="HEAD" DIFF_TARGET="WORKTREE" \
python pull_code.py
# 下游 qa-test-points 消费变更集（解耦）
CHANGED_FILES_JSON="work/targets/.pull_result.json" TP_SCOPE="全部" \
python ../../test-accel/gen_test_points.py
```

## 十、文件夹只读管控（权限保护）★ 新增
被测代码仓库（`LOCAL_PATH`）默认应处于**只读**状态，避免任何环节误改被测对象。
本技能在执行拉取时按以下时序管理权限：

1. **拉取代码前**：若目录已存在，立即将其（含全部文件与 `.git`，递归）设为**只读**。
   目的：保护被测代码，任何非本技能写入都被 OS 拒绝。
2. **执行拉取操作（克隆 / fetch --deepen / checkout / 变更集计算）前**：临时切换为**读写**，
   否则 git 无法写 `.git/objects` 与工作树。
3. **拉取完成后**：**立即恢复只读**，使被测仓库回到受保护状态。

实现：`_set_readonly(local, readonly)` —— Windows 用 `ctypes.windll.kernel32.SetFileAttributesW`
逐文件置/清 `FILE_ATTRIBUTE_READONLY` 位（仅对目录置位不会阻止内部文件写入，故逐文件递归）；
POSIX 用 `chmod a-w / a+w`。**任何权限操作异常均被吞掉，绝不中断拉取流程**（退出码恒 0）。

结果 JSON 含 `perm` 字段反映状态：
```json
"perm": {
  "readonly_before_pull": true,
  "restored_after_pull": true,
  "note": "拉取前已置只读；写仓库操作期间临时读写；拉取完成已恢复只读"
}
```
> 说明：下游 `qa-test-points`（只读扫描工作树）与 Playwright 执行（只读访问线上）均不写仓库，
> 故拉取后保持只读不影响后续测试点生成与执行；下次再拉取时本技能在第 2 步自动放开。

> ⚠️ **误伤防护**：若 `--path` 指向的目录 `.git` 损坏导致 git 顶层逃逸到父项目，
> 本技能返回 `repo_escape_blocked` 并拒绝继续（绝不 diff/checkout 父仓库）。
> 修复方式：在该目录内 `git init` 重建为独立仓库，或重新克隆。
