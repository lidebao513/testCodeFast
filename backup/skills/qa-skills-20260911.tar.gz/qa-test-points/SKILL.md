---
name: qa-test-points
description: >
  测试点（Test Points）生成与对比能力。当用户要求「生成测试点 / 测试范围 / 测试知识点 /
  测试覆盖 / 测试矩阵」，或给定仓库、分支、对比基线并说「生成测试点」，或需要把「旧版（模块级）」
  与「新版（代码级）」测试点做对比、标注「全量 / 更新」或范围（正常 / 异常 / 安全 / 边界）时使用。
  **执行层**（UI / 接口）由 `VerifyLayer` 枚举决定，是执行阶段的选择，不属于生成阶段的范围维度。
  **本技能只生成测试点，不拉取代码**——被测代码须已由 qa-code-pull 技能备好（或手动就位）。
agent_created: true
---

# 测试点生成（Test Points）技能

将「依据完整代码静态扫描派生测试点」的能力系统整理为可复用流程：支持**范围参数（Scope）**过滤、
**全量 / 更新**双标签、旧版 vs 新版对比（MD + HTML）、控制台重打印。全部可复现，不依赖 LLM。

## 一、何时使用（触发条件）
- 用户说「生成测试点 / 测试范围 / 测试知识点 / 测试覆盖」。
- 用户给定仓库 / 分支 / 对比基线，要求「跑一遍代码、出测试点」。
- 评审测试点：旧版（报告第二章 9 模块级抽样）vs 新版（依完整代码生成 · 代码级全面覆盖）。
- 需要在每条测试点旁标注「全量 / 更新」两类，或按「正常 / 异常 / 安全 / 边界」筛选生成。
- **前提**：被测代码已就位（由 `qa-code-pull` 技能拉取并切到目标版本，或手动准备）。本技能不负责拉代码。

## 二、入参与调用时机（与 qa-code-pull 解耦）
| 参数 | 环境变量 | 默认 | 说明 |
|---|---|---|---|
| 仓库路径 | `TP_REPO_PATH` | `work/targets/research-agent` | 已就位的本地仓库（由 qa-code-pull 备好） |
| diff 基线 | `TP_DIFF_BASE` | `test-20260906` | 与 qa-code-pull 的 `DIFF_BASE` 是同一契约值 |
| diff 目标 | `TP_DIFF_TARGET` | `test-20260907` | 工作树应处于此版本 |
| 变更文件集 | `CHANGED_FILES_JSON` | 空 | **可选**：指向 `qa-code-pull` 产出的 result JSON，直接读其 `changed_files`，不调用 git、不 import qa-code-pull |
| 范围 | `TP_SCOPE` 或 `argv[1]` | 空 → 默认 `正常+边界` | 见第三节 |

**调用时机**：**先 `qa-code-pull`，后 `qa-test-points`**。本技能是纯「读工作树 + 生成」，只读、不改仓库。
**结果处理**：生成 4 份产物（见第十节），并在控制台 `[5/5]` 段重打印最新测试点。

## 三、测试点范围参数（Scope）★ 核心
测试点按 **行为维度 `tp_type`**（正常/异常/安全/边界）分类。所有枚举值（含 `tp_type`、
`tag`、`ftype`、`verify_layer`、`dimension`、`status` 等）已集中定义于
`work/test-accel/backend/core/enums.py`（**单一真值源**），各模块统一 import 引用，
禁止在代码中硬编码字面量（详见该文件与 `scripts/check_enums.py` 门禁）。

> **执行层（UI / 接口）不是生成阶段的范围维度**，而是执行阶段的选择：每条测试点由
> `derive_verify_layer(ftype)` 推导默认执行层（`api/business → 接口层`，`page/ui/component → UI 层`），
> 字段 `verify_layer` 已注入每条测试点；执行时用户可选 `preferred_layer`，UI 层无法覆盖时由
> `select_execution_mode()` 自动回退接口层并标记 `layer_fallback`。

| 取值 | 类别 | 含义 | 生成/筛选来源 |
|---|---|---|---|
| 正常 | 行为维度 | 功能可用性、业务函数逻辑可用、页面可达 | API 路由、核心业务模块函数、前端页面/组件 |
| 异常 | 行为维度 | 资源不存在(404)、错误处理 | 含 `{id}` 路径参数的 API 路由 |
| 安全 | 行为维度 | 鉴权缺失(401/403)、越权访问 | 所有 API 路由（鉴权）+ 写操作的越权维度 |
| 边界 | 行为维度 | 参数缺失/非法(400/422) | 所有 API 路由 |

**默认范围：正常 + 边界（行为维度，不限来源）。**

**过滤规则（输入驱动）：**
1. 从输入文本提取命中的行为维度 `mentioned`；
2. 若含「全部 / 所有 / 全量 / 完整」→ 四种行为维度都生成、不限来源；
3. 否则若命中行为维度 → 仅生成对应维度；
4. 否则（未指定）→ 使用默认 `{正常, 边界}`（不限来源）。

解析函数（与 `gen_test_points.py` 保持一致，返回 `ScopeSpec`，常量取自 `enums.py`）：
```python
from backend.core.enums import TPType, Tag, FType, VerifyLayer, ALL_TP_TYPES, DEFAULT_SCOPE, FULL_SCOPE

class ScopeSpec:
    def __init__(self, tp_types, kinds=None):
        self.tp_types = tp_types          # 行为维度集合（tp_type 取值见 enums.TPType）
        self.kinds = kinds                 # 通用来源过滤（保留位，当前生成阶段不再用「接口」关键词）

def resolve_scope(input_text: str):
    text = (input_text or "").strip()
    if text and any(k in text for k in ("全部","所有","全量","完整","all","ALL")):
        return ScopeSpec(set(FULL_SCOPE), None)
    mentioned = {s for s in ALL_TP_TYPES if s in text}
    if mentioned:
        return ScopeSpec(mentioned, None)
    return ScopeSpec(set(DEFAULT_SCOPE), None)
```
作用位置：`code_analyzer.generate_comprehensive_test_points(local_path, project_type, changed_files, scopes)`
在「四维展开」之后、打标签/编号/汇总之前按 `tp_type ∈ scopes.tp_types` 过滤。
`scopes=None` 表示不过滤（兼容旧行为，生成全部四种）。

## 四、生成流程（v2 全面覆盖）
1. **获取变更文件**：优先读 `CHANGED_FILES_JSON`（qa-code-pull 产物），否则内部 `git diff --name-only base..target`（read-only）— 用于打「更新」标签。
2. **生成全面测试点**：`generate_comprehensive_test_points(repo, project_type="pc", changed_files, scopes, diff_hunks, diff_target)`：
   - ① API 路由按 path 归入业务模块，每条展开 **正常 / 安全 / 边界** 三维，含 `{id}` 路由追加 **异常** 维，写操作再追加 **越权** 维（安全）；
   - ② 抽取核心业务模块 → 业务级覆盖点（正常）：`discover_business_modules()` 先按显式清单 `_CORE_MODULES`（候选目录已含 `tools/`、`src/` 等重构后路径）命中，不足时按「顶层公共符号数」动态补足（排除 tests/migrations/mock/workspace 噪声与路由主导文件），只取非 `_` 公共符号；
   - ③ 前端页面路由可达（正常）+ 含交互钩子的组件（正常）；
   - **业务语义增强（B2）**：每条测试点补 `semantic`（业务域·动作）、`impl`（实现函数 + docstring），并重写 name/expect 为业务化表述；
   - **功能点业务语义（A1）**：每个功能点补 `fp_id`（稳定哈希 ID）、`module`/`action`/`semantic`/`impl`/`loc`/`title`/业务化 `description`；
   - **双向追溯（A2）**：测试点携带 `fp_id`/`fp_name`/`fp_title`，功能点侧 `fp_index[fp_id]["test_points"]` 反查；
   - **去重扫描（C1）**：`_SourceIndex` 保证同一文件只读一次、只解析一次 AST（功能点/语义/测试点/hunk 打标共用）；
   - 过滤：仅保留 `tp_type ∈ scopes`；
   - 标签：**hunk 级精准打标（B1）**——符号行区间 ∩ diff hunk 区间才标「更新」，无 hunk 数据时自动降级文件级；统一编号 `TP-001…`；按模块汇总。
3. **产出 5 份文件**：JSON（结构化）、NEW.md（逐条 + 类型标识 + 来源功能点）、**FUNCTIONAL_POINTS.md（功能点 → 测试点 追溯矩阵）**、COMPARE.md（旧/新分段对比）、COMPARE.html（旧/新并排可视化 + 逐条表 + 追溯矩阵第五节）。
4. **控制台重打印**：模块汇总（含「更新」命中数）+ 「更新」逐条 + 「全量」前 12 条示例 + **追溯 Top8（fp_id → 派生测试点数）**。

## 五、标签：全量 / 更新（hunk 级 · B1）
- **全量**：代码未变更部分，常规全量回归执行（默认集）。
- **更新**：其底层**符号（路由/函数）的源码行区间**被 `base..target` 的 hunk 覆盖 → 优先回归。
- 粒度：**hunk 级**（不是整文件）。例：`server.py` 只改了 `login`，则只有 `login` 相关测试点标「更新」，其余 40+ 路由仍为「全量」。
- 降级：拿不到 hunk（离线 / 未提供 `diff_hunks` / 该文件无 hunk 条目）时自动回退文件级，**保证不漏标**。
- `diff_target` 非空时用 `git show target:rel` 解析符号，行号与 hunk 严格对齐（防工作树漂移）。

## 六、HTML 报告标题规则 ★
生成 HTML 对比报告（`TEST_POINTS_COMPARE.html`）时，**仅移除**旧版与新版的「文案标题」，
**其下方内容（表格）保持展示**：
- 移除：`<span class="tag old">旧版（上次生成 · 报告第二章 · 9 模块级）</span>`
- 移除：`<span class="tag new">新版（本次 · 依据完整代码生成 · 全面覆盖）</span>`
- 保留：两张卡片内的 `<table>`（旧版 9 模块基线表 / 新版模块汇总表）及后续差异表、逐条徽章表、KPI。
- MD 版（`TEST_POINTS_COMPARE.md`）保留「一、旧版…」「二、新版…」节标题（此规则仅针对 HTML）。

## 七、实现位置（本项目）
- 生成器核心：`work/test-accel/backend/modules/code_analyzer.py`
  - `generate_comprehensive_test_points(...)`（支持 `scopes` / `diff_hunks` / `diff_target`）
  - `compute_diff_changed_files(repo, base, target)`、`compute_diff_hunks(repo, base, target)`
    （内部 read-only 回退；含 `_git_repo_usable()` 防 .git 损坏时向上命中父仓库）
  - **C1 统一契约**：`FP_CONTRACT_VERSION="1.0"`、`fp_id_of(ftype, file, name)`（md5 稳定 ID）、
    `_SourceIndex`（去重扫描：读一次 + AST 解析一次，`aligned=True` 走 `git show target:rel`）
  - **A1 功能点业务语义**：`_enrich_fps` / `_enrich_api_fp` / `_enrich_plain_fp`
  - **A2 双向追溯**：`fp_index`、`traceability`（孤儿测试点应为 0）、`functional_points`
  - **B1 hunk 打标**：`_tag_point`、`_match_changed_rel`、`_route_decorator_info`
  - **B2 测试点语义**：`_enrich_semantic`、`_METHOD_ACTION` / `_BIZ_PATH_RULES` / `_CORE_MODULE_BIZ`
  - **业务模块发现**：`discover_business_modules()`（显式 `_CORE_MODULES` 优先 + 动态补足）、
    `_biz_of_path`（末两段路径 + 关键词词典推导业务域）、`_top_symbols`（仅公共顶层符号）
- 驱动脚本：`work/test-accel/gen_test_points.py`
  - 含 `resolve_scope`、`_badge_md` / `_badge_html`（全量绿 `#3ecf8e` / 更新橙 `#ffb454`）、
    `_load_changed_files`（**解耦消费** qa-code-pull 的 `CHANGED_FILES_JSON`，不 import 对方）、
    `_write_fp_md`（功能点追溯矩阵）、三份写出函数（已落实「HTML 仅移除旧版/新版标题、保留表内容」）。
- 自测脚本：`work/test-accel/selftest_a1_a2_c1.py`（受控 fixture git 仓库 + 真实仓库回归，23 项断言）
- 产物目录：`work/research-agent-test/`
  - `TEST_POINTS_NEW.md`、`TEST_POINTS_COMPARE.md`、`TEST_POINTS_COMPARE.html`、
    `test_points_new.json`、**`FUNCTIONAL_POINTS.md`**

## 八、调用规则（与 qa-code-pull 协作 · 互不干扰）★ 本技能与 `qa-code-pull` 完全独立
| 维度 | qa-code-pull（拉取代码） | qa-test-points（生成测试点） |
|---|---|---|
| 触发条件 | 给出仓库/分支/基线，要「拉取/同步/准备被测代码」 | 要「生成测试点/测试范围/测试覆盖」 |
| 入参命名空间 | `REPO_URL`/`LOCAL_PATH`/`DIFF_BASE`/`DIFF_TARGET`/`DEEPEN`/`PULL_RESULT_JSON` | `TP_REPO_PATH`/`TP_DIFF_BASE`/`TP_DIFF_TARGET`/`CHANGED_FILES_JSON`/`TP_SCOPE` |
| 调用时机 | **先** | **后** |
| 是否依赖对方 | 否（独立克隆/加深/切版本） | 否（只读工作树；变更集可经 `CHANGED_FILES_JSON` 读取，亦可内部计算） |
| 互相 import | 无 | 无 |
| 写出的资源 | 改仓库（fetch/checkout）+ 自有 `.pull_result.json` | `work/research-agent-test/` 下 4 文件 |
| 稳定性保证 | 网络操作全部 try/except+超时+killpg，离线降级，退出码恒 0 | read-only，纯本地文件扫描，不触网 |

**互不干扰要点**：
- 二者**零 import 依赖**，仅通过「文件系统契约」衔接（qa-code-pull 写 `changed_files` → qa-test-points 经 `CHANGED_FILES_JSON` 读取）。
- **环境变量命名空间隔离**（`REPO_*`/`PULL_*` vs `TP_*`），不会因共享变量互相串扰。
- 资源分区：qa-code-pull 写仓库与 `.pull_result.json`；qa-test-points 写 `research-agent-test/` 目录，**不重叠、不互删**。
- 顺序约定：qa-code-pull 完成（仓库就位、工作树=目标版本）后再跑 qa-test-points，避免读到不一致的工作树。
- 二者均**退出码恒 0**，内部异常以 `status` 字段标注，调用方（Agent）不会因之「报错」。

## 九、调用示例
```bash
# 1) 先拉取代码（独立模块，产出 .pull_result.json）
cd ~/.workbuddy/skills/qa-code-pull
python pull_code.py
#   → work/targets/.pull_result.json（含 changed_files 列表）

# 2) 再生成测试点（默认范围 正常+边界，解耦消费 qa-code-pull 产物）
cd work/test-accel
CHANGED_FILES_JSON="work/targets/.pull_result.json" python gen_test_points.py
# 仅安全 / 边界
CHANGED_FILES_JSON="work/targets/.pull_result.json" TP_SCOPE="安全、边界" python gen_test_points.py
# 全部四种
CHANGED_FILES_JSON="work/targets/.pull_result.json" TP_SCOPE="全部" python gen_test_points.py
# 不接 qa-code-pull 也行（内部 read-only git diff 兜底）
TP_SCOPE="全部" python gen_test_points.py

# —— 执行层（VerifyLayer）在「执行阶段」选择，不属于 TP_SCOPE ——
# 每条测试点已带 verify_layer（接口/UI）；执行时由 executor 的 select_execution_mode 决定实际层，
# 偏好 UI 但测试点本质是接口型或无浏览器时自动回退接口层并标记 layer_fallback。

# 阶段2 能力自测（A1 功能点语义 / A2 双向追溯 / C1 统一契约+去重扫描，含 B1 hunk 回归）
python selftest_a1_a2_c1.py      # 退出码 0 = 23 项断言全通过
```

## 十、输出物说明
| 文件 | 内容 |
|---|---|
| `TEST_POINTS_NEW.md` | 新版全部测试点逐条清单，含「类型标识（全量/更新）」彩色徽章列、**来源功能点（fp_id + 业务名）**列、范围概览、图例、模块汇总 |
| `FUNCTIONAL_POINTS.md` | **功能点清单（A1 业务语义）+ 功能点 → 测试点 追溯矩阵（A2）**：fp_id / 类型 / 业务语义 / 文件 / 派生测试点数 / 测试点 ID |
| `TEST_POINTS_COMPARE.md` | 旧版（9 模块级）vs 新版（代码级）分段对比 + 差异分析表 |
| `TEST_POINTS_COMPARE.html` | 旧/新并排可视化 + 逐条表（**旧版/新版文案标题已移除，表内容保留**）+ KPI + **第五节 追溯矩阵** |
| `test_points_new.json` | 结构化数据：`test_points[]`（含 `tp_type`/`tag`/`semantic`/`impl`/`fp_id`/`fp_name`/`fp_title`）、`functional_points[]`、`fp_index`、`traceability`、`scan_stats`、`contract_version` |

**关键字段（统一契约 v1.0）**
| 字段 | 归属 | 含义 |
|---|---|---|
| `fp_id` | FP + TP | 稳定 ID = `FP-` + md5(`ftype|file_path|name`)[:8]，代码不变则 ID 不变 |
| `semantic` | FP + TP | 业务域 · 业务动作（如 `对话/会话 · 流式输出`） |
| `module` / `action` | FP | 业务域 / 业务动作 |
| `impl` | FP + TP | 实现函数名 + docstring 首行（真实业务语义来源） |
| `loc` | FP | 符号源码行区间 `{start,end}` |
| `fp_id` / `fp_name` / `fp_title` | TP | 指向来源功能点（TP → FP） |
| `fp_index[fp_id].test_points` | FP | 派生测试点 ID 列表（FP → TP） |
| `traceability` | 结果 | `fp_total/tp_total/fp_with_tp/coverage/tp_without_fp(orphan)`；**孤儿应恒为 0** |
| `scan_stats` | 结果 | `text_requests > files_read` 证明重复读取被缓存吸收（C1 去重生效） |

## 十一、注意与边界
- `scopes=None` 时不过滤，等价于「全部四种」，与旧行为兼容。
- 标签为 **hunk 级**；merge-base/浅克隆会导致 `git diff` 失真（见 `qa-code-pull` 技能的加深处理）。
- **基线失效保护**：`base`/`target` ref 解析失败时变更文件数 = 0，脚本会打印醒目警告（全部标「全量」），
  需核对 `git rev-parse <base> <target>` 后重跑；若目标目录 `.git` 不完整，git 会向上命中**父仓库**，
  代码内已用 `_git_repo_usable()` 校验 toplevel 并直接返回空集，避免误标。
- 范围过滤发生在编号/汇总之前，故「模块汇总、by_type、by_tag、逐条表」均反映过滤后的集合，统计一致。
- `fp_without_tp > 0` 通常是 Scope 过滤导致（本轮只要正常+边界时，安全/异常派生点被过滤），**不是追溯断链**；
  只有 `tp_without_fp(orphan) > 0` 才是契约缺陷（自测脚本会断言其为 0）。
- **已知环境风险**：被测仓库 `.git` 不完整 / 基线 ref 失效时变更文件数 = 0（见上一条）。
- **业务模块发现**：`_CORE_MODULES` 是**显式优先清单**，命中不足时由 `discover_business_modules()`
  按「顶层公共符号数」动态补足（排除 tests/migrations/mock/workspace 等噪声与路由主导文件），
  业务域由末两段路径 + 关键词词典推导；故后端重构成 `tools/**` 也能正常产出 business 维度。
  调参：`_BUSINESS_MAX_MODULES` / `_BUSINESS_MAX_SYMBOLS` / `_BUSINESS_MIN_SYMBOLS`。
- **解耦**：qa-test-points 不拉代码、不 import qa-code-pull；如需变更集经 `CHANGED_FILES_JSON` 注入，否则内部 read-only 计算，两种方式结果一致。
- 若用户要求「重新输出最新的测试点」，直接用对应 Scope 跑一遍驱动脚本并在控制台查看 `[5/5]` 打印段。
